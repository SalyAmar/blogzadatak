-- phpMyAdmin SQL Dump
-- version 4.9.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jun 26, 2022 at 04:47 PM
-- Server version: 10.5.12-MariaDB
-- PHP Version: 7.3.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `id19093205_blogzadatak`
--

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` int(11) NOT NULL,
  `title` varchar(64) NOT NULL,
  `content` varchar(256) NOT NULL,
  `date` date NOT NULL,
  `imageUrl` text NOT NULL,
  `author` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `title`, `content`, `date`, `imageUrl`, `author`) VALUES
(121, 'The rise and fall of Ext JS', 'For being over a decade old, Ext JS is still a good platform to develop many enterprise-grade (think intranet) applications. From 2006 to 2015, I was actively invested in the Sencha community, answering forum posts, publishing articles, books, screencasts ', '2022-10-14', 'post121.png', 'User'),
(123, 'How to write reliable browser tests using Selenium and Node.js', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam quis pharetra ex. Quisque est mauris, vulputate vitae auctor quis, elementum vitae odio. Sed non sollicitudin dui, a hendrerit enim. Etiam et augue odio. In lacus dolor, tempor ac dolor a, hend', '2016-10-26', 'post62b87b7c6f330.png', 'User'),
(124, '3 Code Splitting Patterns For VueJS andWebpack', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam quis pharetra ex. Quisque est mauris, vulputate vitae auctor quis, elementum vitae odio. Sed non sollicitudin dui, a hendrerit enim. Etiam et augue odio. In lacus dolor, tempor ac dolor a, hend', '2022-06-09', 'post62b87bbb2bd87.png', 'User');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(32) NOT NULL,
  `password` varchar(255) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `first_name`, `last_name`, `email`) VALUES
(39, 'User', 'user', 'User', 'Testuser', 'salihovic.amar22@gmail.com');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=125;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
