<?php include "db.php"; ?>
<?php include "header.php"; ?>
<?php include "functions.php"; ?>

<link rel="stylesheet" href="../css/style.css">
<link href='https://fonts.googleapis.com/css?family=Heebo' rel='stylesheet'>
</head>

<body>
    <nav>
        <div class="heder">
            <a class="links" href="../index.php" style="border: none;">Blog Management</a>
            <div class="rightSection">

                <button class="btn-1" href="newpost.php">New blog post</button>
                <button class="btn-2" href="logout.php">Logout</button>
            </div>
        </div>
    </nav>

    <style>
    .forma {
        margin: auto;
        width: 260px;
        margin-top: 3rem;
    }

    input {
        border: 1px solid;
        border-color: #8DABC4;
        border-radius: 4px;
        padding: 9px 10px 9px 10px;
        width: 100%;
        margin-top: 2px;
        margin-bottom: 5px;

    }

    input[name=password] {
        margin-bottom: 10px;
    }

    button[name=submit] {
        font-family: "Heebo";
        background-color: #2D9CDB;
        color: white;
        width: 100%;
        border-radius: 4px;
        border: none;
        padding: 10px 5px 10px 5px;
    }

    label {
        color: #8DABC4;
        font-weight: 400;
        font-size: 15px;
    }

    @media (max-width: 1000px) {}

    @media (max-width: 400px) {

        .container {
            width: 380px;
        }


        .forma {
            margin-right: 10px;
            margin-top: 50px;
        }
    }
    </style>

    <?php

    if (isset($_POST['submit'])) {

        // Geting values from a form

        $first_name = $_POST['first_name'];
        $last_name = $_POST['last_name'];
        $email = $_POST['email'];
        $username = $_POST['username'];
        $password = $_POST['password'];
        $confirm_password = $_POST['confirm_password'];

        if ($confirm_password !== $password) {
            echo 'Passwords do not match';
        } else {

            // Geting all users and checking if the user already exists

            $query = "SELECT * FROM users";
            $get_users = mysqli_query($connection, $query);
            while ($row = mysqli_fetch_array($get_users)) {

                $database_username = $row['username'];

                if ($username === $database_username) {

                    echo 'Username already exists';
                } else {

                    // Setting Session username to be new registered username

                    $_SESSION['username'] = $username;

                    // Inserting information from register form

                    $query = "INSERT INTO users(first_name, last_name, email, username, password) VALUES('$first_name', '$last_name', '$email', '$username', '$password') ";
                    mysqli_query($connection, $query);
                    redirect('../admin.php');
                }
            }
        }
    }




    ?>

    <main>
        <div class="container">
            <form action="" method="post" class="forma">

                <label for="First Name">
                    First Name <br>
                </label>
                <input name="first_name" type="text" required><br>

                <label for="Last Name">
                    Last Name <br>
                </label>
                <input name="last_name" type="text" required><br>

                <label for="Email">
                    Email <br>
                </label>
                <input name="email" type="email" required><br>

                <label for="username">
                    Username <br>
                </label>
                <input name="username" type="text" required><br>

                <label for="password">
                    Password <br>
                </label>
                <input name="password" type="password" required> <br>

                <label for="Confirm Password">
                    Confirm Password <br>
                </label>
                <input name="confirm_password" type="password" required> <br>
                <button type="submit" name="submit">Register</button>
            </form>
        </div>
    </main>

</body>