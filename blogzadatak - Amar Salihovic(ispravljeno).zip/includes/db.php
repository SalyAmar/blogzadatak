<?php

$connection = mysqli_connect('localhost', 'id19093205_blog', '#kb>$U?JO6A8xpu?', 'id19093205_blogzadatak');

?>