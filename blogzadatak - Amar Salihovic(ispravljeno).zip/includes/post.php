<?php include "db.php"; ?>
<?php include "header.php"; ?>

<link rel="stylesheet" href="../css/style.css">
<link href='https://fonts.googleapis.com/css?family=Heebo' rel='stylesheet'>

</head>

<body>
    <nav>
        <div class="heder">
            <a class="links" href="../index.php">Blog Management</a>
            <div class="rightSection">

            <?php if (isset($_SESSION['username'])) { ?>
                <a href="logout.php"><button class="btn-2">Logout</button></a>
                <?php } else { ?>
                <a href="login.php"><button class="btn-2">Login</button></a>
                <?php } ?>
            </div>
        </div>
    </nav>

    <style>
    .div {
        display: grid;
        grid-template-columns: 60% 40%;
        font-family: "Heebo";
    }

    .div :nth-child(1) {
        margin: auto 0 auto 0;
        font-size: 2rem;

    }

    p {
        font-family: "Heebo";
        font-size: 13px;
        margin-top: 10px;
    }

    @media (max-width: 920px) {

        .div :nth-child(1) {
            margin: auto 0px auto 20px;
            font-size: 25px;
        }
        .div :nth-child(2) {
        margin-right: 50px;

    }

        p {
            font-size: 12px;
            margin-left: 20px;
            margin-right: 20px;
            text-justify: center;
        }
    }

    @media (max-width: 680px) {

.div :nth-child(1) {
    margin: auto 0px auto 20px;
    font-size: 20px;
   
}
.div :nth-child(2) {
margin-right: 50px;
height: 50%;

}

p {
    font-size: 12px;
    margin-left: 20px;
    margin-right: 20px;
    text-justify: center;
}

}

@media (max-width: 680px) {

    .div {
        display: list-item;
    }

.div :nth-child(1) {
    margin: auto 0px auto 20px;
    font-size: 20px;
}
.div :nth-child(2) {
margin-right: 50px;
}

p {
    font-size: 12px;
    margin-left: 20px;
    margin-right: 20px;
    text-justify: center;
}

}


    </style>

    <?php


if(isset($_GET["post_id"])) {

    $post_id = $_GET["post_id"];

$query = "SELECT * FROM posts WHERE id = $post_id ";
$post = mysqli_query($connection, $query);

while($row = mysqli_fetch_array($post)){


$post_id = $row['id'];
$post_title = $row['title'];
$post_date = $row['date'];
$post_image = $row['imageUrl'];
$post_content = $row['content'];

}

}

?>

    <main>
        <div class="container">
            <div class="div">
                <div class="ptitle">
                    Title: <?php echo $post_title ?><br>
                    Date:<?php echo $post_date ?>
                </div>
                <div>
                    <img src="../images/<?php echo $post_image ?>" alt="postphoto" style="width:100%; height:100%;">
                </div>
            </div>
            <div>
                <p><?php echo $post_content ?></p>
            </div>

        </div>

    </main>