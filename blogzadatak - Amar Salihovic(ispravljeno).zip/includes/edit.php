<?php include "db.php"; ?>
<?php include "header.php"; ?>
<?php include "functions.php"; ?>
<link rel="stylesheet" href="../css/style.css">
<link href='https://fonts.googleapis.com/css?family=Heebo' rel='stylesheet'>

</head>
<?php 


$username = $_SESSION['username'];

    if(usernameMatch($username) !== false) {
        header("location:includes/login.php");
        exit();
    } 

?>

<body>
    <nav>
        <div class="heder">
            <a class="links" href="../admin.php">Blog Management</a>
            <div class="rightSection">

                <a href="newpost.php"><button class="btn-1">New blog post</button></a>
                <a href="logout.php"><button class="btn-2">Logout</button></a>
            </div>
        </div>
    </nav>


    <style>
    .pozicija {
        display: grid;
        grid-template-columns: 65% 35%;
    }

    h1 {
        font-family: "Heebo";
        font-size: 25px;
        color: #2C405A;
        margin-top: 20px;
        margin-bottom: 15px;
    }

    label {
        color: #8DABC4;
        font-family: "Heebo";
        font-weight: 400;
        font-size: 13px;
    }

    input {
        width: 95%;
        border: 1px solid;
        border-color: #A8C6DF;
        border-radius: 4px;
        padding: 9px 10px 9px 10px;
        margin-top: 3px;
        margin-bottom: 10px;
    }

    textarea[name="content"] {
        width: 95%;
        border: 1px solid;
        border-color: #A8C6DF;
        border-radius: 4px;
        padding: 9px 10px 250px 10px;
        margin-top: 3px;
        margin-bottom: 10px;

    }

    input[type=date] {
        width: 100%;
    }

    input[type="file"] {
        display: none;
    }



    .btn-cancel {
        background-color: #4F4F4F;
        color: white;
        width: 37%;
        padding: 10px 10px 10px 10px;
        border: none;
        border-radius: 4px;

    }

    button[type="submit"] {
        background-color: #4ECE3D;
        color: white;
        width: 60%;
        padding: 10px 10px 10px 10px;
        border: none;
        border-radius: 4px;
        margin-left: 5px;

    }

    .fileupload {
        font-size: 13px;
        margin-top: 5px;

    }
    </style>
    <?php


if(isset($_GET['post_id'])){
    $post_id =  $_GET['post_id'];
    $_SESSION['id'] = $post_id;
}

$query = "SELECT * FROM posts WHERE ID = $post_id";
$select_posts_by_id = mysqli_query($connection,$query);  

while($row = mysqli_fetch_assoc($select_posts_by_id)) {

    $post_title = $row['title'];
    $post_image = $row['imageUrl'];
    $post_content = $row['content'];
    $post_date = $row['date'];

}

$novo_ime = $post_image;

if(isset($_POST['publish'])) {

    $post_title = $_POST['title'];
    $post_date = $_POST['date'];
    $post_content = $_POST['content'];

//Image file transfer

    if(isset($_FILES['image'])){

    $post_image = $_FILES['image']['name'];
    $tmp_name = $_FILES['image']['tmp_name'];  
    $error = $_FILES['image']['error'];  

    if ($error === 0) {
        $img_ex = pathinfo($post_image, PATHINFO_EXTENSION);
        $img_ex_lc = strtolower($img_ex);
        $novo_ime = 'post'.$_SESSION['id'].'.'.$img_ex_lc;
        $img_upload_path = '../images/'.$novo_ime;
        move_uploaded_file($tmp_name, $img_upload_path);
    }else {
        $error_msg = "Error";
        header("Location: edit.php?error=$error_msg");
    }

    }else {
    $post_image = "default.jpg";
    }

//Database Update Query

    $query = "UPDATE posts SET title = '{$post_title}', date = '{$post_date}', content = '{$post_content}', imageUrl = '$novo_ime'   WHERE ID = $post_id" ;
	mysqli_query($connection, $query);
    header("Location:edit.php?post_id=$post_id");
}      

    ?>


    <main>
        <div class="container">
            <h1>Edit post</h1>
            <form method="post" class="pozicija" enctype="multipart/form-data">
                <div>
                    <label for="title">
                        Title <br>
                    </label>
                    <input type="text" name="title" value="<?php echo $post_title; ?>">
                </div>
                <div>
                    <label for="date">
                        Date <br>
                    </label>
                    <input type="date" name="date" value="<?php echo $post_date; ?>">
                </div>
                <div>
                    <label for="content">
                        Content <br>
                    </label>
                    <textarea type="text" name="content"><?php echo $post_content; ?></textarea>
                </div>
                <div>
                    <label for="image">
                        Featured image <br>
                    </label>


                    <img src="../images/<?php echo $novo_ime; ?>" style="width: 100%; max-height: 230px;" id="postimage"
                        ;>

                    <div class="fileupload" style="display: grid; grid-template-columns:50% 50%;">
                        <label class="custom-file-upload">
                            Select Image
                            <input type="file" name="image" onChange="displayImage(this)">
                        </label>
                        <a href="removeimage.php?delete_image=<?php echo $post_id; ?>"
                            style="color: red; text-align:right; font-family: Heebo; text-decoration: none;  ">Remove
                            Image</a>
                    </div>
                </div>
                <div></div>
                <div>
                    <button class="btn-cancel" onclick="cancel()">Cancel</button>
                    <button name="publish" type="submit">Publish post</button>
                </div>
            </form>
        </div>
        <script>
        function triggerClick(e) {
            document.querySelector('#postimage').click();
        }

        function displayImage(e) {
            if (e.files[0]) {
                var reader = new FileReader();
                reader.onload = function(e) {
                    document.querySelector('#postimage').setAttribute('src', e.target.result);
                }
                reader.readAsDataURL(e.files[0]);
            }
        }
        function cancel(){
            document.location.href = "edit.php";
        }
        </script>
    </main>