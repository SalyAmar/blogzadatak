<?php include "header.php"; ?>
<?php include "functions.php"; ?>

<?php

$username = $_SESSION['username'];

if (usernameMatch($username) !== false) {
    header("Location:login.php");
}

?>

<link rel="stylesheet" href="../css/style.css">
<link href='https://fonts.googleapis.com/css?family=Heebo' rel='stylesheet'>

<body>
    <nav>
        <div class="heder">
            <a class="links" href="../admin.php">Blog Management</a>
            <div class="rightSection">
                <a href="newpost.php"><button class="btn-1">New blog post</button></a>
                <a href="logout.php"><button class="btn-2">Logout</button></a>
            </div>
        </div>
    </nav>
    <style>
        .pozicija {
            display: grid;
            grid-template-columns: 65% 35%;
        }

        h1 {
            font-family: "Heebo";
            font-size: 25px;
            color: #2C405A;
            margin-top: 20px;
            margin-bottom: 15px;
        }

        label {
            color: #8DABC4;
            font-family: "Heebo";
            font-weight: 400;
            font-size: 13px;
        }

        input {
            width: 95%;
            border: 1px solid;
            border-color: #A8C6DF;
            border-radius: 4px;
            padding: 9px 10px 9px 10px;
            margin-top: 3px;
            margin-bottom: 10px;
        }

        textarea[name="content"] {
            width: 95%;
            border: 1px solid;
            border-color: #A8C6DF;
            border-radius: 4px;
            padding: 9px 10px 250px 10px;
            margin-top: 3px;
            margin-bottom: 10px;

        }

        input[type=date] {
            width: 100%;
        }

        input[type="file"] {
            display: none;
        }



        button[name=cancel] {
            background-color: #4F4F4F;
            color: white;
            width: 37%;
            padding: 10px 10px 10px 10px;
            border: none;
            border-radius: 4px;

        }

        button[type="submit"] {
            background-color: #4ECE3D;
            color: white;
            width: 60%;
            padding: 10px 10px 10px 10px;
            border: none;
            border-radius: 4px;
            margin-left: 5px;

        }

        .fileupload {
            font-size: 13px;
            margin-top: 5px;
            display: grid;
            grid-template-columns: 50% 50%;
        }

        #remove {
            color: red;
            text-align: right;
            font-family: Heebo;
            text-decoration: none;
            cursor: pointer;
        }

        .custom-file-upload{
            cursor: pointer;
        }

        @media (max-width: 1000px) {

            .pozicija {
                display: grid;
                grid-template-columns: 65% 35%;
                margin-right: 30px;
                margin-left: 30px;
            }

            h1 {
                margin-left: 30px;
            }

            button[name=cancel] {
                width: 40%;
            }

            button[type="submit"] {
                width: 55%;
                margin-left: 10px;
            }

        }

        @media (max-width: 850px) {

            button[type="submit"] {
                margin-left: 5px;
            }
        }

        @media (max-width: 750px) {

            .pozicija {
                display: grid;
                grid-template-columns: 65% 35%;
                margin-right: 30px;
                margin-left: 30px;
            }

            h1 {
                margin-left: 30px;
            }

        }

        @media (max-width: 620px) {
            h1 {
                margin-left: 30px;
            }

            .pozicija {
                display: grid;
                grid-template-columns: repeat(1, 1fr);
                margin-right: 30px;
                margin-left: 30px;
            }

            input[type=date] {
                width: 95%;
            }

            #postimage {
                height: 100%;

            }

            .img-res {
                width: 95%;
                height: 250px;
                margin-bottom: 40px;
            }


            button {
                margin-bottom: 50px;
            }

            button[type="submit"] {
                width: 53%;
            }

        }
    </style>
    <?php

    if (isset($_POST['publish'])) {

        $img_name = $_FILES['image']['name'];
        $tmp_name = $_FILES['image']['tmp_name'];
        $post_title = $_POST['title'];
        $post_date = $_POST['date'];
        $post_content = $_POST['content'];

        if (isset($img_name)) {

            $img_ex = pathinfo($img_name, PATHINFO_EXTENSION);
            $img_ex_lc = strtolower($img_ex);
            $new_img = 'post' . uniqid() . '.' . $img_ex_lc;
            $img_upload_path = '../images/' . $new_img;
            move_uploaded_file($tmp_name, $img_upload_path);

        } else {
            $new_img = 'default.jpg';
        }

        $username = $_SESSION['username'];
        
        $query = "INSERT INTO posts(title, date, content, imageUrl, author) VALUES('{$post_title}', '{$post_date}', '{$post_content}', '$new_img', '$username') ";
        mysqli_query($connection, $query);
        redirect("../admin.php?message=New Post Added Successfully");
        ob_end_flush();
    }



    ?>
    <main>
        <div class="container">
            <h1>New blog post</h1>
            <form action="newpost.php" method="post" class="pozicija" enctype="multipart/form-data">
                <div>
                    <label for="title">
                        Title <br>
                    </label>
                    <input id="title" type="text" name="title" required>
                </div>
                <div>
                    <label for="date">
                        Date <br>
                    </label>
                    <input id="date" type="date" name="date" required>
                </div>
                <div>
                    <label for="content">
                        Content <br>
                    </label>
                    <textarea id="content" type="textarea" name="content" required></textarea>
                </div>
                <div class="img-res">
                    <label for="image">
                        Featured image <br>
                    </label>

                    <img src="../images/<?php echo $new_img; ?>" style="width: 100%; max-height: 230px;" id="postimage" ;>

                    <div class="fileupload">
                        <label class="custom-file-upload">
                            Select Image
                            <input type="file" name="image" onChange="displayImage(this)">
                        </label>
                        <a id="remove" onclick="removeimage()">
                            Remove Image
                        </a>
                    </div>
                </div>
                <div></div>
                <div>
                    <button name="cancel" onclick="test()">Cancel</button>
                    <button name="publish" type="submit">Publish post</button>
                </div>
            </form>
        </div>
        <script>
            function triggerClick(e) {
                document.querySelector('#postimage').click();
            }

            function displayImage(e) {
                if (e.files[0]) {
                    var reader = new FileReader();
                    reader.onload = function(e) {
                        document.querySelector('#postimage').setAttribute('src', e.target.result);
                    }
                    reader.readAsDataURL(e.files[0]);
                }
            }

            function removeimage() {
                document.getElementById('postimage').src = "../images/defaultimage.jpg";
            }

            document.getElementById("date").valueAsDate = new Date();
           
        </script>
    </main>