<?php

if(isset($_POST['publish'])) {

echo "<pre>", print_r($_FILES['image']['name']), "</pre>";
die();



}