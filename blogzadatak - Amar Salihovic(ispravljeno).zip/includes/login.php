<?php include "db.php"; ?>
<?php include "header.php"; ?>
<?php include "functions.php"; ?>

<link rel="stylesheet" href="../css/style.css">
<link href='https://fonts.googleapis.com/css?family=Heebo' rel='stylesheet'>
</head>

<body>
    <nav>
        <div class="heder">
            <a class="links" href="../index.php" style="border: none;">Blog Management</a>
            <div class="rightSection">

                <button class="btn-1" href="newpost.php">New blog post</button>
                <button class="btn-2" href="logout.php">Logout</button>
            </div>
        </div>
    </nav>

    <style>
    .forma {
        margin: auto;
        width: 260px;
        margin-top: 3rem;
    }

    input {
        border: 1px solid;
        border-color: #8DABC4;
        border-radius: 4px;
        padding: 9px 10px 9px 10px;
        width: 100%;
        margin-top: 2px;
        margin-bottom: 5px;

    }

    input[name=password] {
        margin-bottom: 10px;
    }

    button[name=submit] {
        font-family: "Heebo";
        background-color: #2D9CDB;
        color: white;
        width: 100%;
        border-radius: 4px;
        border: none;
        padding: 10px 5px 10px 5px;
    }

    label {
        color: #8DABC4;
        font-weight: 400;
        font-size: 15px;
    }

    @media (max-width: 1000px) {}

    @media (max-width: 400px) {

        .container {
            width: 380px;
        }


        .forma {
            margin-right: 10px;
            margin-top: 50px;
        }
    }

    /* #register {
            text-decoration: none;
        } */
    </style>

    <?php

    if (isset($_POST['submit'])) {

        $username = $_POST['username'];
        $password = $_POST['password'];

        $query = "SELECT * FROM users ";
        $getuser = mysqli_query($connection, $query);

        while ($row = mysqli_fetch_array($getuser)) {

            $dbus = $row['username'];
            $dbpw = $row['password'];

            if ($username == $dbus && $password == $dbpw) {

                $_SESSION['username'] = $username;
                $_SESSION['password'] = $password;
                redirect("../admin.php");

            } else {

                echo "Incorrect password";
                $_SESSION['username'] = null;
                $_SESSION['password'] = null;
            }
        }
    }



    ?>

    <main>
        <div class="container">
            <form action="" method="post" class="forma">
                <label for="">
                    Username <br>
                </label>
                <input name="username" type="text"><br>
                <label for="">
                    Password <br>
                </label>
                <input name="password" type="password"> <br>
                <button type="submit" name="submit">Proceed
                    to login</button>
                <a id="register" href="register.php">Don't have an account? Register Now</a>
            </form>
        </div>
    </main>

</body>