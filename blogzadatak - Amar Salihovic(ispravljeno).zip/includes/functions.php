<?php

function usernameMatch($username) {

    if(empty($username)){

        $result = true;

    } else {
        $result = false;
    }
    return $result;
}

function redirect($location){

    header("Location:" . $location);
    exit;

}

?>