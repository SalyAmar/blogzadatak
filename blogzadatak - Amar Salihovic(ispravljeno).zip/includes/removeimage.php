<?php 
include("db.php");


if(isset($_GET['delete_image'])) {

$post_id = $_GET['delete_image'];
$query = "UPDATE posts SET imageUrl = 'defaultimage.jpg' WHERE ID = $post_id ";
$delete_image_query = mysqli_query($connection, $query);
header("Location: edit.php?post_id=$post_id ");


}


?>