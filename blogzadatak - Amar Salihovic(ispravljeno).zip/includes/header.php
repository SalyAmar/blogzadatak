<?php ob_start()?>
<?php session_start(); ?>
<?php include "db.php"; ?>
<link rel="stylesheet" href="css/style.css">
<link href='https://fonts.googleapis.com/css?family=Heebo' rel='stylesheet'>


<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
    * {
        box-sizing: border-box;
        margin: 0;
        padding: 0;
    }

    nav {
        overflow: hidden;
        background-color: #333333;
        padding: 10px 0px 10px 0px;
    }

    .heder {
        max-width: 900px;
        margin: auto;
    }

    .links {
        font-family: 'Heebo', sans-serif;
        font-weight: 400;
        float: left;
        color: white;
        text-align: center;
        padding: 12px;
        text-decoration: none;
        font-size: 15px;
        border-radius: 4px;
    }

    .btn-1 {
        background-color: #4ECE3D;
        color: white;
        text-align: center;
        padding: 12px;
        font-size: 13px;
        border-radius: 4px;
        border: none;
    }

    .btn-2 {

        background-color: #4F4F4F;
        color: white;
        text-align: center;
        padding: 12px;
        font-size: 13px;
        border-radius: 4px;
        border: none;
        margin-top: 4px;
    }

    .rightSection {
        float: right;
    }





    @media screen and (max-width: 900px) {
        nav {

            padding-right: 30px;
            padding-left: 30px;

        }
    }

 


    </style>
</head>