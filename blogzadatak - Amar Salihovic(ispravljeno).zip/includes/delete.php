<?php include "db.php"; ?>

<?php 

if(isset($_GET['post_id'])) {

$del = $_GET['post_id'];

$query = "DELETE FROM posts WHERE id=$del ";
mysqli_query($connection, $query);
header('Location:../admin.php');
}




?>