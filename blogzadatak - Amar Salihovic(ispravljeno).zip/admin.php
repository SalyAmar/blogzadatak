<?php include "includes/db.php"; ?>
<?php include "includes/header.php"; ?>
<?php include "includes/functions.php"; ?>

<link rel="stylesheet" href="css/style.css">
<link href='https://fonts.googleapis.com/css?family=Heebo' rel='stylesheet'>
</head>
<?php

$username = $_SESSION['username'];

if (!isset($_SESSION['username'])) {
    redirect('includes/login.php');
}

?>

<body>
    <nav>
        <div class="heder">
            <a class="links" href="#">Blog Management</a>
            <div class="rightSection">

                <a href="includes/newpost.php"><button class="btn-1">New blog post</button></a>


                <a href="includes/logout.php"><button class="btn-2">Logout</button></a>


            </div>


        </div>
    </nav>
    <main>
        <div class="container">
            <h1>Blog post list</h1>
            <style>
                h1 {
                    font-family: "Heebo";
                    font-size: 25px;
                    color: #2C405A;
                    margin-top: 20px;
                    margin-bottom: 15px;
                }

                table {
                    width: 100%;
                    border-collapse: collapse;
                    margin-top: 20px;

                }

                thead tr :nth-child(1) {
                    border-right: 0px;
                }

                thead tr :nth-child(2) {
                    border-right: 0px;
                    border-left: 0px;
                }

                thead tr :nth-child(3) {
                    border-left: 0px;
                }

                tbody tr :nth-child(1) {
                    border-right: 0px;
                }

                tbody tr :nth-child(2) {
                    border-right: 0px;
                    border-left: 0px;
                }

                tbody tr :nth-child(3) {

                    border-left: 0px;
                }

                td,
                th {
                    border: 1px solid;
                    padding: 10px;
                    border-color: #B7D2E5;
                    font-family: "Heebo";
                }

                thead tr th {
                    text-align: left;
                    padding: 5px;
                }

                thead tr :nth-child(1) {
                    width: 60%;

                }

                thead tr :nth-child(2) {
                    width: 20%;

                }

                thead tr :nth-child(3) {
                    text-align: right;
                    width: 100px;


                }

                tbody tr :nth-child(3) {
                    text-align: right;

                }

                tbody tr td img {
                    text-align: right;
                    margin: 0 15px 0 15px;
                }


                @media (max-width: 900px) {

                    table {
                        margin: auto;
                        width: 95%;

                    }

                    h1 {
                        margin-left: 45px;
                    }

                    img[alt="post"] {
                        width: 15px;
                    }

                    img[alt="edit"] {
                        width: 15px;
                    }

                    img[alt="delete"] {
                        width: 13px;
                    }

                    tbody tr td img {
                        text-align: right;
                        margin: 0 10px 0 10px;
                    }

                    .datum {
                        font-size: 14px;

                    }
                }

                @media (max-width: 820px) {


                    table {
                        margin: auto;
                        width: 95%;

                    }

                    h1 {
                        margin-left: 40px;

                    }

                    .posttitl {
                        white-space: nowrap;
                        overflow: hidden;
                        text-overflow: ellipsis;
                        max-width: 50px;
                    }

                    img[alt="post"] {
                        width: 12px;

                    }

                    img[alt="edit"] {
                        width: 12px;
                    }

                    img[alt="delete"] {
                        width: 11px;
                    }

                    tbody tr td img {
                        text-align: right;
                        margin: 0 10px 0 10px;
                    }

                    .datum {
                        font-size: 15px;

                    }

                }

                @media (max-width: 770px) {


                    table {
                        margin: auto;
                        width: 95%;

                    }

                }

                @media (max-width: 680px) {


                    table {
                        margin: auto;
                        width: 95%;

                    }

                }

                @media (max-width: 650px) {


                    table {
                        margin: auto;
                        width: 95%;

                    }

                    h1 {
                        margin-left: 15px;
                    }

                    .posttitl {
                        font-size: 15px;
                    }

                    img[alt="post"] {
                        width: 10px;
                    }

                    img[alt="edit"] {
                        width: 10px;
                    }

                    img[alt="delete"] {
                        width: 9px;
                    }

                }

                @media (max-width: 620px) {


                    table {
                        margin: auto;
                        width: 95%;

                    }

                    h1 {
                        margin-left: 15px;
                    }

                    .posttitl {
                        font-size: 15px;
                    }

                    img[alt="post"] {
                        width: 10px;

                    }

                    img[alt="edit"] {
                        width: 10px;

                    }

                    img[alt="delete"] {
                        width: 9px;

                    }

                    .datum {
                        font-size: 12px;

                    }

                    tbody tr td img {
                        text-align: right;
                        margin: 0 5px 0 5px;
                    }

                }


                @media (max-width: 400px) {


                    table {
                        margin: auto;
                        width: 95%;

                    }

                    h1 {
                        margin-left: 15px;
                    }

                    .posttitl {
                        font-size: 12px;
                    }

                    img[alt="post"] {
                        width: 10px;

                    }

                    img[alt="edit"] {
                        width: 10px;

                    }

                    img[alt="delete"] {
                        width: 9px;

                    }

                    .datum {
                        font-size: 10px;

                    }

                    tbody tr td img {
                        text-align: right;
                        margin: 0 1px 0 1px;
                    }

                }

                #message {
                    width: 100%;
                    height: 40px;
                    padding: 10px 0 10px 0;
                    background-color: rgb(124, 252, 0, 0.4);
                    text-align: center;
                }
            </style>

            <span id="message">
                <?php

                // echo $_SESSION['message'];
                if (isset($_GET['message'])) {
                    $message = $_GET['message'];
                    echo $message;
                }


                ?>
            </span>
            <table>
                <thead>
                    <tr>
                        <th>TITLE</th>
                        <th>DATE</th>
                        <th>ACTIONS</th>
                    </tr>

                </thead>
                <tbody>

                    <?php

                    $query = "SELECT * FROM posts WHERE author = '" . $username . "'  ORDER BY id DESC";
                    $admin_post = mysqli_query($connection, $query);

                    while ($row = mysqli_fetch_array($admin_post)) {

                        $post_title = $row['title'];
                        $post_date = $row['date'];
                        $post_id = $row['id'];
                
                    ?>
                       
                            
                        <tr>
                            <td class="posttitl"><?php echo $post_title ?></td>
                            <td class="datum"><?php echo $post_date ?></td>
                            <div>
                                <td class="ikone">

                                    <a href="includes/post.php?post_id=<?php echo $post_id ?>"><img src="images/Globe.png" alt="post"></a>
                                    <a href="includes/edit.php?post_id=<?php echo $post_id ?>"><img src=" images/Icon.png" alt="edit"></a>
                                    <a onclick="delete_post(<?php echo $post_id; ?>)"><img src="images/Icone.png" alt="delete"></a>
                                </td>
                            </div>
                        </tr>

        

                    <?php } ?>
                </tbody>
            </table>


        </div>

    </main>
    <script>
        function delete_post(post_id) {
            if (confirm("Are you sure you want to delete this post?")) {
                window.location.href = 'includes/delete.php?post_id=' + post_id + '';
                return true
            }
        }

        let paramaters = new URLSearchParams(window.location.search);
        let message = paramaters.get('message');

        if (message) {
            document.getElementById('message').style.display = "block";
            setTimeout(() => {
                const box = document.getElementById('message');
                // 👇️ removes element from DOM
                box.style.display = 'none';
                // 👇️ hides element (still takes up space on page)
            }, 10000);
        } else {
            document.getElementById('message').style.display = "none";
        }
    </script>