<?php include "includes/db.php"; ?>
<?php include "includes/header.php"; ?>
<?php include "includes/functions.php"; ?>

<link rel="stylesheet" href="css/style.css">
</head>


<body>
    <nav>
        <div class="heder">
            <a class="links" href="admin.php">Blog Management</a>
            <div class="rightSection">

                <a href="includes/newpost.php"><button class="btn-1">New blog post</button></a>

                <?php if (isset($_SESSION['username'])) { ?>
                    <a href="includes/logout.php"><button class="btn-2">Logout</button></a>
                <?php } else { ?>
                    <a href="includes/login.php"><button class="btn-2" href="includes/login.php">Login</button></a>
                <?php } ?>
            </div>
        </div>
    </nav>
    <style>
        .container {

            display: grid;
            grid-template-columns: repeat(3, 1fr);
            grid-gap: 10px;

        }

        .prikaz div h2 {

            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            max-width: 290px;

        }

        h2 {
            font-family: "Heebo";
            font-size: 17px;
            margin-top: 5px;
        }

        p {
            font-size: 13px;
            margin-bottom: 10px;
        }

        button[name=read] {
            font-family: "Heebo";
            width: 100%;
            background-color: #4ECE3D;
            color: white;
            text-align: center;
            padding: 10px;
            font-size: 13px;
            border-radius: 4px;
            border: none;

        }


        @media (max-width: 920px) {


            .container {
                display: grid;
                grid-template-columns: repeat(2, 1fr);
                grid-gap: 15px;
                margin-left: 50px;
                margin-right: 50px;
            }

            .sve {
                margin-top: 15px;
            }

        }

        @media (max-width: 650px) {
            .container {
                display: grid;
                grid-template-columns: repeat(1, 1fr);
                grid-gap: 10px;
            }

            .sve {
                width: 80%;
                height: 120%;
                margin: auto;
            }

        }


        @media (max-width: 500px) {
            .container {
                display: grid;
                grid-template-columns: repeat(1, 1fr);
                grid-gap: 10px;
            }

            .sve {
                width: 80%;
                height: 120%;
                margin: auto;
            }

        }
    </style>

    <main>
        <div class="container">

            <?php

            $username = $_SESSION['username'];

            $query = "SELECT * FROM posts ORDER BY id DESC";

            $postovi = mysqli_query($connection, $query);

            while ($row = mysqli_fetch_array($postovi)) {


                $post_id = $row['id'];
                $post_title = $row['title'];
                $post_date = $row['date'];
                $post_image = $row['imageUrl'];


            ?>

                <div class="sve">
                    <img src="images/<?php echo $post_image ?>" style="height: 220px; width:100%;">
                    <div class="prikaz">
                        <div>
                            <h2> <?php echo $post_title ?> </h2>
                        </div>
                        <div>
                            <p> Date <?php echo $post_date ?></p>
                        </div>
                        <div> <a href="includes/post.php?post_id=<?php echo $post_id ?>"> <button name="read">Read
                                    More</button>
                        </div>
                        </a>
                    </div>
                </div>
            <?php } ?>
        </div>
    </main>

</body>

</html>